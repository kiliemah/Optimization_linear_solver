import matplotlib.pyplot as plt
import numpy as np


class plot(object):
    def __init__(self,f,function_name) -> None:
        self.f = f
        self.function_name = function_name
        
    
    def path(self, path_lists):
        """
        This function plot the path of a minimization algorthims on the contours of a given function
        Parameters
        ------------
        path_lists : np.ndarray of np.ndarray
            an array that contain the path array for each meathod
        """

        # Create x and y coordinate arrays
        if self.function_name == "circle":
            xx = np.linspace(-2, 2, 100)
            yy = np.linspace(-2, 2, 100)
        if self.function_name in ["elipse","rot_elipse"] :
            xx = np.linspace(-2, 2, 100)
            yy = np.linspace(-2, 2, 100)
        if self.function_name == "line":
            xx = np.linspace(-1000, 1000, 100)
            yy = np.linspace(-1000, 1000, 100)
        if self.function_name == "rosenbrock":
            xx = np.linspace(-2, 2, 100)  
            yy = np.linspace(-1, 3, 100)
        if self.function_name == "function_g":
            xx = np.linspace(-2, 2, 1000)
            yy = np.linspace(-2, 2, 1000)

        X, Y = np.meshgrid(xx , yy)

        # computing Contour values
        i=0
        Z = []
        for y in yy:
            j=0
            axis_y=[]
            for x in xx:
                location = np.array([x,y])
                f_value=self.f(location, h_flag = False)[0]
                axis_y.append(f_value)
                j+=1
            Z.append(axis_y)
            i+=1
        
        colors = ["red","blue","purple","pink"]
        methods = ["GD", "Newton", "SR1", "BFGS"]
        # Create a contour plot
        plt.contourf(X, Y, Z, levels=20, cmap='viridis') #'viridis' 'coolwarm' 'RdGy' 'jet' 'inferno', 'plasma'
        plt.colorbar()
        plt.xlabel('X')
        plt.ylabel('Y')
        plt.title("contour lines of "+self.function_name)
        for i in range(len(path_lists)):
            path_x = path_lists[i][:,0] 
            path_y = path_lists[i][:,1] 
            plt.plot(path_x, path_y, color=colors[i], label=methods[i])
        # Display the plot
        plt.legend()
        plt.show()
    
    def iteration(self, values_lists):
        """
        This function plot the function value at each iteration
        ------------
        values_lists : np.ndarray of np.ndarray
            an array that contain the minimization values array for each meathod
        """

        colors = ["red","blue","purple","pink"]
        methods = ["GD", "Newton", "SR1", "BFGS"]

        for i in range(len(values_lists)):
            iter = range(values_lists[i].shape[0])
            plt.plot(iter, values_lists[i], color=colors[i], label=methods[i])
        plt.title(" Function value by iteration - "+self.function_name)
        plt.legend()
        plt.xlabel('iterations')
        plt.ylabel('f(x)')
        plt.show()

        





