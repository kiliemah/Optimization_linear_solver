import numpy as np

class unconstraint(object):

    """
    This class solve an unconstraint optimisation problem

    Parameters
    ------------
    f : Python function that return a np.ndarray of shape (3,)
        function to minimize. The function should return 3 value
        - f(x),
        - the gradient at x 
        - The Hessian at x if needed
    x_0 : np.ndarray
        initial function value (starting location of the optimizer)
    obj_tol : float
        the numeric tolerance for successful termination in terms of small enough
        change in objective function values, between two consecutive iterations
    param_tol : flaot
        the numeric tolerance for successful termination in terms of small enough
        distance between two consecutive iterations iteration locations
    max_iter : int
        the maximum allowed number of iterations
    method : string
        Optimization method 
        - Gradient Descent : "GD"
        - Newton Method : "Newton"
        - SR1 : "SR1"
        - BFGS : "BFGS"
    c_1 : float
        Wolfe condition constant c_1, float number between 0 and 1
    back : float
        backtracking, float number between 0 and 1

    
    Return 
    ------------
    x_path : nd.array of shape (n,k) 
        where n is the number of explored location 
        and k is the dimenssion of x_0
        Location x , and function value f(x) at each iteration during the minimization process
    f_path_loc : ndarray of shape (n,)
        The value of f at a given location in the optimization path
    final_x : nd.array of the size of x_0
        Final location x that minimize the function
    final_f_x : float
        The function value at the final location that minimize f (the min of the function)
    status : bool
        Boolean (True or False) that say if the optimization process is a success or failure

    """
    
    def __init__(self, f, x_0, obj_tol, param_tol, max_iter, method, c_1, back) -> None:
        
        # initialization attribute
        self.f = f
        self.x_0 = x_0
        self.obj_tol = obj_tol
        self.param_tol = param_tol
        self.max_iter = max_iter
        self.method = method
        self.c_1 = c_1
        self.back = back

        # results attributes
        self.x_path = None
        self.f_path_loc = None
        self.final_x = None
        self.final_f_x = None
        self.status = False



    def find_step(self, x, f_i, g_i, p):
        """
        function that compute the next location according the wolf condition

        Paratmeters
        -----------
        x : current location
        f_i : f at the current location x
        p : founded direction
        g_i :  gradient at the current location i
        alpha_space : np.ndarray where values are between 0 and 1
        
        return 
        -----------
        x_step : next location to investigate
        """
        alpha = 1
        while True:
            x_step = x + alpha * p
            f_x_step = self.f(x_step,h_flag=False)[0]
            wolf_cond_1 = f_i + (self.c_1 * alpha * np.dot(g_i, p))
            if f_x_step <=  wolf_cond_1 :
                return x_step,f_x_step
            alpha = self.back * alpha
            

    
    def GD(self):
        """
        This function compute the minimimun ot the function according gradient descent method
        It update the corresponding attribute 

            self.path 
            self.final_x 
            self.final_f_x 
            self.status 

        which are the return values of the optimization process

        """
        stop_check = 1000 # init objectif tolerence stopping condition
        distance_check = 1000 # init distance tolerence stopping condition 
        x = [self.x_0] # list locations visited
        f_x = [self.f(self.x_0, h_flag=False)[0]] # list of function value at the location isited 
        p = None # direction to visit
        print("******* Gradient Descent ************")
        for i in range(self.max_iter):

            if stop_check < self.obj_tol or distance_check < self.param_tol:
                # Up the status flag in case we reached a minimum by stopping condition
                self.status = True
                break
            else :
                g = self.f(x[i], h_flag=False)[1]
                p = -g
                next_x, f_next_x = self.find_step(x[-1],f_x[-1], g, p)
                x.append(next_x)
                f_x.append(f_next_x)
                stop_check = np.abs(f_x[-1] - f_x[-2])
                distance_check = np.linalg.norm(x[-1] - x[-2])
        
        # In case the number of iteration is reached OR we break the loop by a stop condtition
        # We update the finals results
        self.final_x = x[-1]
        self.final_f_x = f_x[-1]
        self.x_path = np.array(x)
        self.f_path_loc = np.array(f_x)
        print("> Iteration ",i,":")
        print("     - location :",x[-1])
        print("     - f(x)     :",f_x[-1])
        print("     - status :", self.status,"\n")

        
        
        
    def Newton(self):
        """
        This function compute the minimimun ot the function according Newton method
        It update the corresponding attribute 

            self.path 
            self.final_x 
            self.final_f_x 
            self.status 

        which are the return values of the optimization process
        """
        stop_check = 1000 # init objectif tolerence stopping condition
        distance_check = 1000 # init distance tolerence stopping condition 
        x = [self.x_0] # list locations visited
        f_x = [self.f(self.x_0, h_flag=False)[0]] # list of function value at the location isited 
        p = None # direction to visit
        print(" ************ Newton Method ************ ")
        for i in range(self.max_iter):
            if  distance_check < self.param_tol or np.abs(stop_check) < self.obj_tol: # Checking distance between 2 last locations
                # Up the status flag in case we reached a minimum by distance stopping condition
                self.status = True
                break
            else :
                g, H = self.f(x[-1], h_flag=True)[1:]
                try:
                    p = np.linalg.solve(H, -g)
                except:
                    break
                next_x, f_next_x = self.find_step(x[-1],f_x[-1], g, p)
                x.append(next_x)
                f_x.append(f_next_x)
                stop_check = np.abs(f_x[-1] - f_x[-2])
                distance_check = np.linalg.norm(x[-1] - x[-2])
        
        # In case the number of iteration is reached OR we break the loop by a stop conditition
        # We update the finals results
        # Status attribute stay False in case we didn't reach a minimum over all iterations
        self.final_x = x[-1]
        self.final_f_x = f_x[-1]
        self.x_path = np.array(x)
        self.f_path_loc = np.array(f_x)
        print("> Iteration ",i,":")
        print("     - location :",x[-1])
        print("     - f(x)     :",f_x[-1])
        print("     - status :", self.status,"\n")
        

    def SR1_Hessian_approx(self, B:np.ndarray, x_i, next_x):
        """
        This function compute the hessian approximation for the SR1 algorithm
        """
        s = next_x - x_i
        y = self.f(next_x, h_flag=False)[1] - self.f(x_i, h_flag=False)[1]
        a = y - np.dot(B,s)
        if np.dot(a,s) == 0:
            return B
        next_B = B + np.outer(a,a.T)/(np.dot(a,s))
        return next_B
        
        
        
    def SR1(self):
        """
        This function compute the minimimun ot the function according Newton method
        It update the corresponding attribute 

            self.path 
            self.final_x 
            self.final_f_x 
            self.status 

        which are the return values of the optimization process

        """       
        stop_check = 1000 # init objectif tolerence stopping condition
        distance_check = 1000 # init distance tolerence stopping condition 
        x = [self.x_0] # list locations visited
        f_x = [self.f(self.x_0, h_flag=False)[0]] # list of function value at the location isited 
        p = None # direction to visit
        B = self.f(self.x_0, h_flag=True)[2]
    
        print(" ************ SR1 ************ ")
        for i in range(self.max_iter):
            if stop_check < self.obj_tol or distance_check < self.param_tol:
                # Up the status flag in case we reached a minimum by stopping condition
                self.status = True
                break
            else :
                g = self.f(x[-1], h_flag=True)[1]
                try:
                    p = np.linalg.solve(B, -g)
                except:
                    break
                # Now we find the next step
                next_x, f_next_x = self.find_step(x[-1],f_x[-1], g, p)
                distance_check = np.linalg.norm(next_x - x[-1])
                stop_check = np.abs(f_next_x - f_x[-1])
                B = self.SR1_Hessian_approx(B, x[-1], next_x)
                x.append(next_x)
                f_x.append(f_next_x) 
                
        # In case the number of iteration is reached OR we break the loop by a stop conditition
        # We update the finals results
        # Status attribute stay False in case we didn't reach a minimum over all iterations
        self.final_x = x[-1]
        self.final_f_x = f_x[-1]
        self.x_path = np.array(x)
        self.f_path_loc = np.array(f_x)
        print("> Iteration ",i,":")
        print("     - location :",x[-1])
        print("     - f(x)     :",f_x[-1])
        print("     - status :", self.status,"\n")

    def BFGS_Hessian_approx(self, B:np.ndarray, x_i, next_x):
        """
        This function compute the hessian approximation for the BFSG algorithm
        """
        s = next_x - x_i
        y = self.f(next_x, h_flag=False)[1] - self.f(x_i, h_flag=False)[1]
        Bs = np.dot(B,s)
        if (np.dot(y,s))==0 or (s.T.dot(B.dot(s)))==0 :
            return B
        next_B = B - ((np.outer(Bs,Bs)) / (s.T.dot(B.dot(s)))) + ((np.outer(y,y)) / (np.dot(y,s)))
        return next_B
    

    def BFGS(self):
        """
        This function compute the minimimun ot the function according Newton method
        It update the corresponding attribute 

            self.path 
            self.final_x 
            self.final_f_x 
            self.status 

        which are the return values of the optimization process

        """
        stop_check = 1000 # init objectif tolerence stopping condition
        distance_check = 1000 # init distance tolerence stopping condition 
        x = [self.x_0] # list locations visited
        f_x = [self.f(self.x_0, h_flag=False)[0]] # list of function value at the location isited 
        p = None # direction to visit
        # initialization of B
        B = self.f(self.x_0, h_flag=True)[2]
        print(" ************ BFGS ************ ")
        for i in range(self.max_iter):
            if stop_check < self.obj_tol or distance_check < self.param_tol:
                # Up the status flag in case we reached a minimum by stopping condition
                self.status = True
                break
            else :
                g = self.f(x[-1], h_flag=True)[1]
                try:
                    p = np.linalg.solve(B, -g)
                except:
                    break
                # Now we find the next step
                next_x, f_next_x = self.find_step(x[-1],f_x[-1], g, p)
                distance_check = np.linalg.norm(next_x - x[-1])
                stop_check = np.abs(f_next_x - f_x[-1])
                B = self.BFGS_Hessian_approx(B, x[-1], next_x)
                x.append(next_x)
                f_x.append(f_next_x)       
        
        # In case the number of iteration is reached OR we break the loop by a stop conditition
        # We update the finals results
        # Status attribute stay False in case we didn't reach a minimum over all iterations
        self.final_x = x[-1]
        self.final_f_x = f_x[-1]
        self.x_path = np.array(x)
        self.f_path_loc = np.array(f_x)
        print("> Iteration ",i,":")
        print("     - location :",x[-1])
        print("     - f(x)     :",f_x[-1])
        print("     - status :", self.status,"\n")

    def Minimize(self):
        """
        running function
        run funcion in terms of what methot the user sepcify
        """
        if self.method == "GD":
            self.GD()
        if self.method == "Newton":
            self.Newton()
        if self.method == "SR1":
            self.SR1()
        if self.method == "BFGS":
            self.BFGS()
