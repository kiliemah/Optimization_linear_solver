import numpy as np

def circle(x: np.ndarray, h_flag: bool) -> np.ndarray:
    """
    function of circles contour lines 

    Parameters
    ------------
    x : np.ndarray
        location vector
    h_flag : bool
        hessian flag say that, if we need to implement the hessian matrix or not

    return
    ------------
    result : an np.ndarray of shape (3,) composed of

        - f : the index 0
            the scalar function value at x
        - g : the index 1
            the gradient vector at x
        - h : the index 2
            the Hessian matrix (if needed only)

    """
    Q = np.array([[1,0],[0,1]])

    f = np.dot(np.dot(x.T,Q),x) # value of the function at x
    g = 2 * np.dot(Q,x) # gradient of f
    if h_flag == True:
        h = 2*Q  # hessian at x if needed
    else:
        h = None  # hessian if not needed
    
    result = np.array([f,g,h],dtype=object)
    return result



def elipse(x: np.ndarray, h_flag: bool) -> np.ndarray:
    """
    function of elipses contour lines

    Parameters
    ------------
    x : float
        location vector
    h_flag : bool
        hessian flag say that, if we need to implement the hessian matrix or not
    
    return
    ------------
    result : an np.ndarray of shape (3,) composed of

        - f : the index 0
            the scalar function value at x
        - g : the index 1
            the gradient vector at x
        - h : the index 2
            the Hessian matrix (if needed only)

    
    """
    Q =np.array([[1,0],[0,100]])

    f = np.dot(np.dot(x.T,Q),x) # value of the function at x
    g = 2 * np.dot(Q,x) # gradient of f
    if h_flag == True:
        h = 2*Q  # hessian at x if needed
    else:
        h = None  # hessian if not needed
    
    result = np.array([f,g,h],dtype=object)
    return result


def rot_elipse(x: np.ndarray, h_flag: bool) -> np.ndarray:
    """
    function of rotated elipses contour lines

    Parameters
    ------------
    x : float
        location vector
    h_flag : bool
        hessian flag say that, if we need to implement the hessian matrix or not
    
        
    return
    ------------
    result : an np.ndarray of shape (3,) composed of

        - f : the index 0
            the scalar function value at x
        - g : the index 1
            the gradient vector at x
        - h : the index 2
            the Hessian matrix (if needed only)

    """
    Q_1 =np.array([[(np.sqrt(3)/2),-0.5],[0.5,(np.sqrt(3)/2)]])
    Q_2 =np.array([[100,0],[0,1]])
    Q = np.dot(np.dot(Q_1.T,Q_2),Q_1)

    f = np.dot(np.dot(x.T,Q),x) # value of the function at x
    g = 2 * np.dot(Q,x) # gradient of f
    if h_flag == True:
        h = 2*Q  # hessian at x if needed
    else:
        h = None  # hessian if not needed

    result = np.array([f,g,h],dtype=object)
    return result


def rosenbrock(x: np.ndarray, h_flag: bool) -> np.ndarray:
    """
    function of rotated elipses contour lines

    Parameters
    ------------
    x : float
        location vector
    h_flag : bool
        hessian flag say that, if we need to implement the hessian matrix or not
    
        
    return
    ------------
    result : an np.ndarray of shape (3,) composed of

        - f : the index 0
            the scalar function value at x
        - g : the index 1
            the gradient vector at x
        - h : the index 2
            the Hessian matrix (if needed only)

    """

    f = 100*np.square((x[1]-np.square(x[0]))) + np.square(1-x[0])

    g_1 = 400*(x[0]**3) - 400*x[1]*x[0] + 2*x[0] - 2
    g_2 = -200*(x[0]**2) + 200*x[1]
    g = np.array([g_1,g_2])

    if h_flag == True:
        h_11 = 1200 * (x[0]**2) - 400*x[1] + 2
        h_12 = - 400 * x[0]
        h_21 =  h_12
        h_22 = 200
        h = np.array([[h_11,h_12],[h_21,h_22]]) # hessian at x if needed


    else:
        h = None  # hessian if not needed

    result = np.array([f,g,h],dtype=object)
    return result


def line(x: np.ndarray, h_flag: bool) -> np.ndarray:
    """
    function of rotated elipses contour lines

    Parameters
    ------------
    x : float
        location vector
    h_flag : bool
        hessian flag say that, if we need to implement the hessian matrix or not
    
        
    return
    ------------
    result : an np.ndarray of shape (3,) composed of

        - f : the index 0
            the scalar function value at x
        - g : the index 1
            the gradient vector at x
        - h : the index 2
            the Hessian matrix (if needed only)

    """
    a = np.array([3,7])
    f = np.dot(a.T,x)
    g = a

    if h_flag == True:
        h = np.array([[0,0],[0,0]]) # hessian at x if needed
    else:
        h = None  # hessian if not needed

    result = np.array([f,g,h],dtype=object)
    return result


def function_g(x: np.ndarray, h_flag: bool) -> np.ndarray:
    """
    function of rotated elipses contour lines

    Parameters
    ------------
    x : float
        location vector
    h_flag : bool
        hessian flag say that, if we need to implement the hessian matrix or not
    
        
    return
    ------------
    result : an np.ndarray of shape (3,) composed of

        - f : the index 0
            the scalar function value at x
        - g : the index 1
            the gradient vector at x
        - h : the index 2
            the Hessian matrix (if needed only)

    """
    
    f = np.exp(x[0]+3*x[1]-0.1) + np.exp(x[0]-3*x[1]-0.1) + np.exp(-x[0]-0.1)
    g_1 = np.exp(x[0]+3*x[1]-0.1) + np.exp(x[0]-3*x[1]-0.1) - np.exp(-x[0]-0.1)
    g_2 = 3 * np.exp(x[0]+3*x[1]-0.1) - 3 * np.exp(x[0]-3*x[1]-0.1) 
    g = np.array([g_1,g_2])

    if h_flag == True:
        h_11 = np.exp(x[0]+3*x[1]-0.1) + np.exp(x[0]-3*x[1]-0.1) + np.exp(-x[0]-0.1)
        h_12 = 3 * np.exp(x[0]+3*x[1]-0.1) - 3 * np.exp(x[0]-3*x[1]-0.1)
        h_21 = h_12
        h_22 = 9 * np.exp(x[0]+3*x[1]-0.1) + 9 * np.exp(x[0]-3*x[1]-0.1)
        h = np.array([[h_11,h_12],[h_21,h_22]]) # hessian at x if needed
    else:
        h = None  # hessian if not needed

    result = np.array([f,g,h],dtype=object)
    return result
