import sys
import os

# Get the src directory
subfolder_path = os.path.dirname("src")
sys.path.append(subfolder_path)

from src import unconstraint_min, utils
from examples import *
import unittest

class Test(unittest.TestCase):
    """
    This class compute the minimization for 6 functions. 
    For each functions it uses 4 optimization methods
        - Gradient Descent
        - Newton Method
        - SR1
        - BFGS
    """

    def circle(self):
        # initializing parameters
        x_0 = np.array([1,1]) 
        obj_tol = 10**(-12)
        param_tol = 10**(-8)
        max_iter = 100
        method = ["GD","Newton","SR1","BFGS"]
        c_1 = 0.01 
        back = 0.5 
        opt_GD = unconstraint_min.unconstraint(circle, x_0, obj_tol, param_tol, max_iter, method[0], c_1, back)
        opt_Newton = unconstraint_min.unconstraint(circle, x_0, obj_tol, param_tol, max_iter, method[1], c_1, back)
        opt_SR1 = unconstraint_min.unconstraint(circle, x_0, obj_tol, param_tol, max_iter, method[2], c_1, back)
        opt_BFGS = unconstraint_min.unconstraint(circle, x_0, obj_tol, param_tol, max_iter, method[3], c_1, back)

        opt_GD.Minimize()
        opt_Newton.Minimize()
        opt_SR1.Minimize()
        opt_BFGS.Minimize()

        plot = utils.plot(f=circle, function_name="circle")

        paths_by_methods = [opt_GD.x_path,
                            opt_Newton.x_path,
                            opt_SR1.x_path,
                            opt_BFGS.x_path]

        f_path_loc_by_methods= [opt_GD.f_path_loc,
                                opt_Newton.f_path_loc,
                                opt_SR1.f_path_loc,
                                opt_BFGS.f_path_loc]

        plot.path(paths_by_methods)
        plot.iteration(f_path_loc_by_methods)
        

    def elipse(self):
        # initializing parameters
        x_0 = np.array([1,1]) 
        obj_tol = 10**(-12)
        param_tol = 10**(-8)
        max_iter = 100
        method = ["GD","Newton","SR1","BFGS"]
        c_1 = 0.01 
        back = 0.5 
        opt_GD = unconstraint_min.unconstraint(elipse, x_0, obj_tol, param_tol, max_iter, method[0], c_1, back)
        opt_Newton = unconstraint_min.unconstraint(elipse, x_0, obj_tol, param_tol, max_iter, method[1], c_1, back)
        opt_SR1 = unconstraint_min.unconstraint(elipse, x_0, obj_tol, param_tol, max_iter, method[2], c_1, back)
        opt_BFGS = unconstraint_min.unconstraint(elipse, x_0, obj_tol, param_tol, max_iter, method[3], c_1, back)

        opt_GD.Minimize()
        opt_Newton.Minimize()
        opt_SR1.Minimize()
        opt_BFGS.Minimize()

        plot = utils.plot(f=elipse, function_name="elipse")

        paths_by_methods = [opt_GD.x_path,
                            opt_Newton.x_path,
                            opt_SR1.x_path,
                            opt_BFGS.x_path]

        f_path_loc_by_methods= [opt_GD.f_path_loc,
                                opt_Newton.f_path_loc,
                                opt_SR1.f_path_loc,
                                opt_BFGS.f_path_loc]

        plot.path(paths_by_methods)
        plot.iteration(f_path_loc_by_methods)
        

    def rot_elipse(self):
        # initializing parameters
        x_0 = np.array([1,1]) 
        obj_tol = 10**(-12)
        param_tol = 10**(-8)
        max_iter = 100
        method = ["GD","Newton","SR1","BFGS"]
        c_1 = 0.01 
        back = 0.5 
        opt_GD = unconstraint_min.unconstraint(rot_elipse, x_0, obj_tol, param_tol, max_iter, method[0], c_1, back)
        opt_Newton = unconstraint_min.unconstraint(rot_elipse, x_0, obj_tol, param_tol, max_iter, method[1], c_1, back)
        opt_SR1 = unconstraint_min.unconstraint(rot_elipse, x_0, obj_tol, param_tol, max_iter, method[2], c_1, back)
        opt_BFGS = unconstraint_min.unconstraint(rot_elipse, x_0, obj_tol, param_tol, max_iter, method[3], c_1, back)

        opt_GD.Minimize()
        opt_Newton.Minimize()
        opt_SR1.Minimize()
        opt_BFGS.Minimize()

        plot = utils.plot(f=rot_elipse, function_name="rot_elipse")

        paths_by_methods = [opt_GD.x_path,
                            opt_Newton.x_path,
                            opt_SR1.x_path,
                            opt_BFGS.x_path]

        f_path_loc_by_methods= [opt_GD.f_path_loc,
                                opt_Newton.f_path_loc,
                                opt_SR1.f_path_loc,
                                opt_BFGS.f_path_loc]

        plot.path(paths_by_methods)
        plot.iteration(f_path_loc_by_methods)
        

    def line(self):
        # initializing parameters
        x_0 = np.array([1,1]) 
        obj_tol = 10**(-12)
        param_tol = 10**(-8)
        max_iter = 100
        method = ["GD","Newton","SR1","BFGS"]
        c_1 = 0.01 
        back = 0.5 
        opt_GD = unconstraint_min.unconstraint(line, x_0, obj_tol, param_tol, max_iter, method[0], c_1, back)
        opt_Newton = unconstraint_min.unconstraint(line, x_0, obj_tol, param_tol, max_iter, method[1], c_1, back)
        opt_SR1 = unconstraint_min.unconstraint(line, x_0, obj_tol, param_tol, max_iter, method[2], c_1, back)
        opt_BFGS = unconstraint_min.unconstraint(line, x_0, obj_tol, param_tol, max_iter, method[3], c_1, back)

        opt_GD.Minimize()
        opt_Newton.Minimize()
        opt_SR1.Minimize()
        opt_BFGS.Minimize()

        plot = utils.plot(f=line, function_name="line")

        paths_by_methods = [opt_GD.x_path,
                            opt_Newton.x_path,
                            opt_SR1.x_path,
                            opt_BFGS.x_path]

        f_path_loc_by_methods= [opt_GD.f_path_loc,
                                opt_Newton.f_path_loc,
                                opt_SR1.f_path_loc,
                                opt_BFGS.f_path_loc]

        plot.path(paths_by_methods)
        plot.iteration(f_path_loc_by_methods)
           

    def rosenbrock(self):
        # initializing parameters
        x_0 = np.array([-1,2])
        obj_tol = 10**(-12)
        param_tol = 10**(-8)
        max_iter = 100
        method = ["GD","Newton","SR1","BFGS"]
        c_1 = 0.01 
        back = 0.5 
        opt_GD = unconstraint_min.unconstraint(rosenbrock, x_0, obj_tol, param_tol, 10000, method[0], c_1, back)
        opt_Newton = unconstraint_min.unconstraint(rosenbrock, x_0, obj_tol, param_tol, max_iter, method[1], c_1, back)
        opt_SR1 = unconstraint_min.unconstraint(rosenbrock, x_0, obj_tol, param_tol, max_iter, method[2], c_1, back)
        opt_BFGS = unconstraint_min.unconstraint(rosenbrock, x_0, obj_tol, param_tol, max_iter, method[3], c_1, back)

        opt_GD.Minimize()
        opt_Newton.Minimize()
        opt_SR1.Minimize()
        opt_BFGS.Minimize()

        plot = utils.plot(f=rosenbrock, function_name="rosenbrock")

        paths_by_methods = [opt_GD.x_path,
                            opt_Newton.x_path,
                            opt_SR1.x_path,
                            opt_BFGS.x_path]

        f_path_loc_by_methods= [opt_GD.f_path_loc,
                                opt_Newton.f_path_loc,
                                opt_SR1.f_path_loc,
                                opt_BFGS.f_path_loc]

        plot.path(paths_by_methods)
        plot.iteration(f_path_loc_by_methods)
            

    def function_g(self):
        # initializing parameters
        x_0 = np.array([1,1]) 
        obj_tol = 10**(-12)
        param_tol = 10**(-8)
        max_iter = 100
        method = ["GD","Newton","SR1","BFGS"]
        c_1 = 0.01 
        back = 0.5 
        opt_GD = unconstraint_min.unconstraint(function_g, x_0, obj_tol, param_tol, max_iter, method[0], c_1, back)
        opt_Newton = unconstraint_min.unconstraint(function_g, x_0, obj_tol, param_tol, max_iter, method[1], c_1, back)
        opt_SR1 = unconstraint_min.unconstraint(function_g, x_0, obj_tol, param_tol, max_iter, method[2], c_1, back)
        opt_BFGS = unconstraint_min.unconstraint(function_g, x_0, obj_tol, param_tol, max_iter, method[3], c_1, back)

        opt_GD.Minimize()
        opt_Newton.Minimize()
        opt_SR1.Minimize()
        opt_BFGS.Minimize()

        plot = utils.plot(f=function_g, function_name="function_g")

        paths_by_methods = [opt_GD.x_path,
                            opt_Newton.x_path,
                            opt_SR1.x_path,
                            opt_BFGS.x_path]

        f_path_loc_by_methods= [opt_GD.f_path_loc,
                                opt_Newton.f_path_loc,
                                opt_SR1.f_path_loc,
                                opt_BFGS.f_path_loc]

        plot.path(paths_by_methods)
        plot.iteration(f_path_loc_by_methods)
            


test = Test()
test.circle()
test.elipse()
test.rot_elipse()
test.line()
test.rosenbrock()
test.function_g()